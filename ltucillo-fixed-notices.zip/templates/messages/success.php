<?php
use LTucillo\View\Messages\SuccessMessage;
/** @var SuccessMessage $this */ ?>
<div class = "notice notice-success">
    <p><?php echo $this->getMessage() ?></p>
</div>
