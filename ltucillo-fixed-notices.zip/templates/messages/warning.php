<?php
use LTucillo\View\Messages\WarningMessage;
/** @var WarningMessage $this */ ?>
<div class = "notice notice-warning">
    <p><?php echo $this->getMessage() ?></p>
</div>
