<?php
use LTucillo\View\Messages\InfoMessage;
/** @var InfoMessage $this */ ?>
<div class = "notice notice-info">
    <p><?php echo $this->getMessage() ?></p>
</div>
